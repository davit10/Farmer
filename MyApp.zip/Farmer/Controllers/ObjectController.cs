﻿using AutoMapper;
using FarmingApp.Models;
using FarmingApp.Models.Request_Models;
using FarmingApp.Models.Response_Model;
using FarmingApp.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FarmingApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ObjectController : ControllerBase
    {
        IObjectService _os;
        IMapper _mapper;

        public ObjectController(IObjectService os, IMapper mapper)
        {
            _os = os;
            _mapper = mapper;
        }

        [HttpGet]

        public IActionResult GetAllObjects()
        {
            var objects = _os.GetAll();
            var newObjects = new List<ObjectsResponseModel>();

            foreach (var obj in objects)
            {
                var response = _mapper.Map<ObjectsResponseModel>(obj);

                newObjects.Add(response);
            }

            return Ok(newObjects);
        }

        [HttpPost]

        public IActionResult AddNewObject(ObjectsRequestModel objects)
        {
            var obj = _mapper.Map<Objects>(objects);
            _os.AddObjects(obj);
            return Ok();
        }

        [HttpDelete]

        public IActionResult RemoveObject(int id)
        {
            _os.DeleteObjects(id);
            return Ok();
        }

        [HttpPut]

        public IActionResult UpdateObject(int id, ObjectsRequestModel obj)
        {
            var ob = _mapper.Map<Objects>(obj);
            ob.Id = id;

            _os.UpdateObjects(ob);

            return Ok();
        }
    }
}
