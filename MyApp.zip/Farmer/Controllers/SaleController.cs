﻿using AutoMapper;
using FarmingApp.Models;
using FarmingApp.Models.Request_Models;
using FarmingApp.Models.Response_Model;
using FarmingApp.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FarmingApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SaleController : ControllerBase
    {
        //SaleService ss;
        ISaleService ss;
        IMapper _mapper;

        public SaleController(IMapper mapper, ISaleService saleService)
        {
            //ss = new SaleService();
            ss = saleService;
            _mapper = mapper;
        }

        [HttpGet]

        public IActionResult GetAllSales()
        {
            var sales = ss.GetSales();
            var saleResponses = new List<SaleResponseModel>();

            foreach (var sale in sales)
            {
                var response = _mapper.Map<SaleResponseModel>(sale);

                saleResponses.Add(response);
                //new SaleResponseModel
                //{
                //    Id = sale.Id,
                //    ProductId = sale.ProductId,
                //    Product = sale.Product,
                //    Kg = sale.Kg,
                //    PriceKg = sale.PriceKg,
                //    BuyerId = sale.BuyerId,
                //    Buyer = sale.Buyer,
                //    PayedAmount = sale.PayedAmount,
                //    Date = sale.Date,
                //    Credit = sale.Kg * sale.PriceKg - sale.PayedAmount
                //}
            }



            return Ok(saleResponses);
        }

        [HttpPost]

        public IActionResult AddNewSale(SaleRequestModel saleRequest)
        {
            var sale = _mapper.Map<Sale>(saleRequest);

            //var sale = new Sale
            //{
            //    ProductId = saleRequest.ProductId,
            //    Kg = saleRequest.Kg,
            //    PriceKg = saleRequest.PriceKg,
            //    BuyerId = saleRequest.BuyerId,
            //    PayedAmount = saleRequest.PayedAmount,
            //    Date = DateTime.Now,

            //};

            ss.AddSales(sale);
            return Ok();

        }

        [HttpDelete]

        public IActionResult RemoveSale(int id)
        {
            ss.DeleteSale(id);
            return Ok();
        }

        [HttpPut]

        public IActionResult UpdateSale(int id, SaleRequestModel sale)
        {
            var sl = _mapper.Map<Sale>(sale);
            sl.Id = id;

            ss.UpdateSale(sl);

            return Ok();
        }
    }
}
