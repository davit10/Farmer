﻿using AutoMapper;
using FarmingApp.Models;
using FarmingApp.Models.Request_Models;
using FarmingApp.Models.Response_Model;
using FarmingApp.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FarmingApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TreatmentController : ControllerBase
    {
        ITreatmentService ts;
        IMapper _mapper;


        public TreatmentController(IMapper mapper, ITreatmentService _ts)
        {
            ts = _ts;
            _mapper = mapper;
        }

        [HttpGet]

        public IActionResult GetAllTreatments()
        {
            var treatments = ts.GetTreatments();
            var treatmentResponses = new List<TreatmentResponseModel>();

            foreach (var treatment in treatments)
            {
                var response = _mapper.Map<TreatmentResponseModel>(treatment);

                treatmentResponses.Add(response);

            }



            return Ok(treatmentResponses);
        }

        [HttpPost]

        public IActionResult AddNewSale(TreatmentRequestModel treatmentRequest)
        {
            var treatment = _mapper.Map<Treatment>(treatmentRequest);


            ts.AddTreatment(treatment);
            return Ok();

        }

        [HttpDelete]

        public IActionResult RemoveTreatment(int id)
        {
            ts.DeleteTreatment(id);
            return Ok();
        }

        [HttpPut]

        public IActionResult UpdateTreatment(int id, TreatmentRequestModel treatment)
        {
            var tr = _mapper.Map<Treatment>(treatment);
            tr.Id = id;

            ts.UpdateTreatment(tr);

            return Ok();
        }
    }
}
