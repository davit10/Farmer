﻿using AutoMapper;
using FarmingApp.Models;
using FarmingApp.Models.Request_Models;
using FarmingApp.Models.Response_Model;
using FarmingApp.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FarmingApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        IProductService ps;
        IMapper _mapper;

        public ProductController(IProductService _ps, IMapper mapper)
        {
            ps = _ps;
            _mapper = mapper;
        }

        [HttpGet]

        public IActionResult GetAllProducts()
        {
            var products = ps.GetProducts();
            var newProducts = new List<ProductResponseModel>();
            foreach (var product in products)
            {
                var response = _mapper.Map<ProductResponseModel>(product);

                newProducts.Add(response);
            }
            return Ok(newProducts);
        }

        [HttpPost]

        public IActionResult AddNewProduct(ProductRequestModel product)
        {
            var products = _mapper.Map<Product>(product);

            ps.AddProducts(products);
            return Ok();
        }

        [HttpDelete]

        public IActionResult RemoveProduct(int id)
        {
            ps.DeleteProduct(id);
            return Ok();
        }

        [HttpPut]

        public IActionResult UpdateProduct(int id, ProductRequestModel productRequest)
        {
            var product = _mapper.Map<Product>(productRequest);
            product.Id = id;
            ps.UpdateProduct(product);
            return Ok();
        }
    }
}
