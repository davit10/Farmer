﻿using AutoMapper;
using FarmingApp.Models;
using FarmingApp.Models.Request_Models;
using FarmingApp.Models.Response_Model;
using FarmingApp.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FarmingApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExpenseController : ControllerBase
    {
        IExpenseService es;
        IMapper _mapper;

        public ExpenseController(IExpenseService _es, IMapper mapper)
        {
            es = _es;
            _mapper = mapper;
        }

        [HttpGet]

        public IActionResult GetAllExpenses()
        {
            var expenses = es.GetExpenses();
            var expenseResponses = new List<ExpenseResponseModel>();

            foreach (var expense in expenses)
            {
                var response = _mapper.Map<ExpenseResponseModel>(expense);

                expenseResponses.Add(response);
            }

            return Ok(expenseResponses);
        }

        [HttpPost]

        public IActionResult AddNewExpenses(ExpenseRequestModel expenseRequest)
        {
            var expense = _mapper.Map<Expense>(expenseRequest);
            es.AddExpense(expense);
            return Ok();
        }

        [HttpDelete]

        public IActionResult RemoveExpense(int id)
        {
            es.DeleteExpense(id);
            return Ok();
        }

        [HttpPut]

        public IActionResult UpdateExpense(int id, ExpenseRequestModel expense)
        {
            var ex = _mapper.Map<Expense>(expense);
            ex.Id = id;

            es.UpdateExpense(ex);

            return Ok();
        }
    }
}
