﻿using AutoMapper;
using FarmingApp.Models;
using FarmingApp.Models.Request_Models;
using FarmingApp.Models.Response_Model;
using FarmingApp.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FarmingApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BuyerController : ControllerBase
    {
        IBuyerService bs;
        IMapper _mapper;

        public BuyerController(IBuyerService buyerService, IMapper mapper)
        {
            bs = buyerService;
            _mapper = mapper;
        }

        [HttpGet]

        public IActionResult GetAllBuyers()
        {
            var buyers = bs.GetBuyers();
            var BuyerResponses = new List<BuyerResponseModel>();
            
            foreach (var buyer in buyers)
            {
                var response = _mapper.Map<BuyerResponseModel>(buyer);

                BuyerResponses.Add(response);
            }

            return Ok(BuyerResponses);
        }

        [HttpPost]

        public IActionResult AddNewBuyer(BuyerRequestModel buyerRequest)
        {

            var buyer = _mapper.Map<Buyer>(buyerRequest);

            bs.AddBuyer(buyer);
            return Ok();
        }

        [HttpDelete]

        public IActionResult RemoveBuyer(int id)
        {
            bs.DeleteBuyer(id);
            return Ok();
        }

        [HttpPut]

        public IActionResult UpdateBuyer(int id, BuyerRequestModel buyer)
        {
            var by = _mapper.Map<Buyer>(buyer);
            by.Id = id;

            bs.UpdateBuyer(by);

            return Ok();
        }
    }
}
