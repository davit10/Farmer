﻿using AutoMapper;
using FarmingApp.Models;
using FarmingApp.Models.Request_Models;
using FarmingApp.Models.Response_Model;
using FarmingApp.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FarmingApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InvestorController : ControllerBase
    {
        IInvestorService ins;
        IMapper _mapper;

        public InvestorController(IInvestorService investorService, IMapper mapper)
        {
            ins = investorService;
            _mapper = mapper;
        }

        [HttpGet]

        public IActionResult GetAllInvestors()
        {
            var investors = ins.GetInvestors();
            var investorResponses = new List<InvestorResponseModel>();

            foreach (var investor in investors)
            {
                var response = _mapper.Map<InvestorResponseModel>(investor);

                investorResponses.Add(response);
            }

            return Ok(investorResponses);
        }

        [HttpPost]

        public IActionResult AddNewInvestor(InvestorRequestModel investorRequset)
        {

            var investors = _mapper.Map<Investor>(investorRequset);
            ins.AddInvestors(investors);

            return Ok();
        }

        [HttpDelete]

        public IActionResult RemoveInvestor(int id)
        {
            ins.DeleteInvestor(id);
            return Ok();
        }

        [HttpPut]

        public IActionResult UpdateInvestor(int id, InvestorRequestModel investor)
        {
            var inv = _mapper.Map<Investor>(investor);
            inv.Id = id;

            ins.UpdateInvestor(inv);

            return Ok();
        }
    }
}
