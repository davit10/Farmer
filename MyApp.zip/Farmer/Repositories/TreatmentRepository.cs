﻿using AutoMapper;
using FarmingApp.Models;
namespace FarmingApp.Repositories
{
    public interface ITreatmentRepository
    {
        List<Treatment> GetAll();
        void Add(Treatment treatment);
        void Update(Treatment treatment);
        void Delete(int id);
    }
    public class TreatmentRepository : ITreatmentRepository
    {
        FarmerDbContext db;
        IMapper mapper;

        public TreatmentRepository(FarmerDbContext context, IMapper map)
        {
            db = context;
            mapper = map;

        }
        public void Add(Treatment treatment)
        {
            db.Treatments.Add(treatment);
            db.SaveChanges();
        }

        public void Delete(int id)
        {
            var treatment = db.Treatments.FirstOrDefault(t => t.Id == id);
            db.Treatments.Remove(treatment);
            db.SaveChanges();
        }

        public List<Treatment> GetAll()
        {
            return db.Treatments.ToList();

        }

        public void Update(Treatment treatment)
        {
            var t = db.Treatments.FirstOrDefault(x => x.Id == treatment.Id);

            mapper.Map(treatment, t);

            db.Treatments.Update(t);
            db.SaveChanges();
        }
    }
}
