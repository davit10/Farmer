﻿using AutoMapper;
using FarmingApp.Models;

namespace FarmingApp.Repositories
{
    public interface IInvestorRepository
    {
        List<Investor> GetAll();
        void Add(Investor investor);
        void Update(Investor investor);
        void Delete(int id);
    }
    public class InvestorRepository : IInvestorRepository
    {
        FarmerDbContext context;
        IMapper mapper;
        public InvestorRepository(FarmerDbContext db, IMapper map)
        {
            context = db;
            mapper = map;
        }
        public void Add(Investor investor)
        {
            context.Investors.Add(investor);
            context.SaveChanges();
        }

        public void Delete(int id)
        {
            var inv = context.Investors.FirstOrDefault(x => x.Id == id);
            context.Investors.Remove(inv);
            context.SaveChanges();
        }

        public List<Investor> GetAll()
        {
            return context.Investors.ToList();
        }

        public void Update(Investor investor)
        {
            var inv = context.Investors.FirstOrDefault(i => i.Id == investor.Id);
            mapper.Map(investor, inv);

            context.Investors.Update(inv);
            context.SaveChanges();
        }
    }
}
