﻿using AutoMapper;
using FarmingApp.Models;

namespace FarmingApp.Repositories
{
    public interface IObjectsRepository
    {
        List<Objects> GetAll();
        void Add(Objects obj);
        void Update(Objects obj);
        void Delete(int id);
    }
    public class ObjectsRepository : IObjectsRepository
    {
        FarmerDbContext db;
        IMapper mapper;

        public ObjectsRepository(FarmerDbContext _db, IMapper _mapper)
        {
            db = _db;
            mapper = _mapper;
        }
        public void Add(Objects obj)
        {
            db.Objects.Add(obj);
            db.SaveChanges();
        }

        public void Delete(int id)
        {
            var obj = db.Objects.FirstOrDefault(x => x.Id == id);
            db.Objects.Remove(obj);
            db.SaveChanges();
        }

        public List<Objects> GetAll()
        {
            return db.Objects.ToList();
        }

        public void Update(Objects objects)
        {
            var obj = db.Objects.FirstOrDefault(o => o.Id == objects.Id);
            mapper.Map(objects, obj);

            db.Objects.Update(obj);
            db.SaveChanges();
        }
    }
}
