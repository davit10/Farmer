﻿using AutoMapper;
using FarmingApp.Models;
using Microsoft.EntityFrameworkCore;

namespace FarmingApp.Repositories
{
    public interface IProductRepository
    {
        List<Product> GetAll();
        void Add(Product product);
        void Update(Product product);
        void Delete(int id);
    }
    public class ProductRepository : IProductRepository
    {
        FarmerDbContext db;
        IMapper mapper;

        public ProductRepository(FarmerDbContext context, IMapper map)
        {
            db = context;
            mapper = map;

        }

        public void Add(Product product)
        {
            db.Products.Add(product);
            db.SaveChanges();
        }

        public void Delete(int id)
        {
            var product = db.Products.FirstOrDefault(p => p.Id == id);
            db.Products.Remove(product);
            db.SaveChanges();
        }

        public List<Product> GetAll()
        {
            return db.Products.Include(p => p.Sales).ToList();
        }

        public void Update(Product pr)
        {
            var product = db.Products.FirstOrDefault(x => x.Id == pr.Id);

            mapper.Map(pr, product);

            db.Products.Update(product);
            db.SaveChanges();

        }
    }
}
