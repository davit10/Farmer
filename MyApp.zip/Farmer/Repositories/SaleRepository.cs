﻿using AutoMapper;
using FarmingApp.Models;

namespace FarmingApp.Repositories
{
    public interface ISaleRepository
    {
        List<Sale> GetAll();
        void Add(Sale sale);
        void Update(Sale sale);
        void Delete(int id);
    }
    public class SaleRepository : ISaleRepository
    {
        FarmerDbContext db;
        IMapper mapper;

        public SaleRepository(FarmerDbContext context, IMapper map)
        {
            db = context;
            mapper = map;

        }
        public void Add(Sale sale)
        {
            db.Sales.Add(sale);
            db.SaveChanges();
        }

        public void Delete(int id)
        {
            var sale = db.Sales.FirstOrDefault(s => s.Id == id);
            db.Sales.Remove(sale);
            db.SaveChanges();
        }

        public List<Sale> GetAll()
        {
            return db.Sales.ToList();

        }

        public void Update(Sale sale)
        {
            var s = db.Sales.FirstOrDefault(x => x.Id == sale.Id);

            mapper.Map(sale, s);

            db.Sales.Update(s);
            db.SaveChanges();
        }
    }
}
