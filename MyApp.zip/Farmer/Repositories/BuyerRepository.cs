﻿using AutoMapper;
using FarmingApp.Models;

namespace FarmingApp.Repositories
{
    public interface IBuyerRepository
    {
        List<Buyer> GetAll();
        void Add(Buyer buyer);
        void Update(Buyer buyer);
        void Delete(int id);
    }
    public class BuyerRepository : IBuyerRepository
    {
        FarmerDbContext _db;
        IMapper _mapper;

        public BuyerRepository(FarmerDbContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }
        public void Add(Buyer buyer)
        {
            _db.Buyers.Add(buyer);
            _db.SaveChanges();
        }

        public void Delete(int id)
        {
            var buyer = _db.Buyers.FirstOrDefault(x => x.Id == id);
            _db.Buyers.Remove(buyer);
            _db.SaveChanges();
        }

        public List<Buyer> GetAll()
        {
            return _db.Buyers.ToList();
        }

        public void Update(Buyer buyer)
        {
            var _buyer = _db.Buyers.FirstOrDefault(x => x.Id == buyer.Id);
            _mapper.Map(buyer, _buyer);

            _db.Buyers.Update(_buyer);
            _db.SaveChanges();
        }
    }
}
