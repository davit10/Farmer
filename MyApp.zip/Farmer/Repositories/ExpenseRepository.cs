﻿using AutoMapper;
using FarmingApp.Models;

namespace FarmingApp.Repositories
{
    public interface IExpenseRepository
    {
        List<Expense> GetAll();
        void Add(Expense expense);
        void Update(Expense expense);
        void Delete(int id);
    }
    public class ExpenseRepository : IExpenseRepository
    {
        FarmerDbContext dbContext;
        IMapper mapper;
        public ExpenseRepository(FarmerDbContext context, IMapper map)
        {
            dbContext = context;
            mapper = map;

        }
        public void Add(Expense expense)
        {
            dbContext.Expenses.Add(expense);
            dbContext.SaveChanges();
        }

        public void Delete(int id)
        {
            var exp = dbContext.Expenses.FirstOrDefault(x => x.Id == id);
            dbContext.Expenses.Remove(exp);
            dbContext.SaveChanges();
        }

        public List<Expense> GetAll()
        {
            return dbContext.Expenses.ToList();
        }

        public void Update(Expense expense)
        {
            var  exp = dbContext.Expenses.FirstOrDefault(e => e.Id == expense.Id);
            mapper.Map(expense, exp);

            dbContext.Expenses.Update(exp);
            dbContext.SaveChanges();
        }
    }
}
