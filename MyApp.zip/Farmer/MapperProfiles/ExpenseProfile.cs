﻿using AutoMapper;
using FarmingApp.Models;
using FarmingApp.Models.Request_Models;
using FarmingApp.Models.Response_Model;

namespace FarmingApp.MapperProfiles
{
    public class ExpenseProfile : Profile
    {
        public ExpenseProfile()
        {
            CreateMap<ExpenseRequestModel, Expense>()
            .ForMember(x => x.Date, opts => opts.MapFrom(y => DateTime.Now));
            CreateMap<Expense, ExpenseResponseModel>();
            CreateMap<Expense, Expense>();
        }
    }
}
