﻿using AutoMapper;
using FarmingApp.Models;
using FarmingApp.Models.Request_Models;
using FarmingApp.Models.Response_Model;

namespace FarmingApp.MapperProfiles
{
    public class SaleProfile : Profile
    {
        public SaleProfile()
        {
            CreateMap<SaleRequestModel, Sale>()
                .ForMember(x => x.Date, opts => opts.MapFrom(y => DateTime.Now));

            CreateMap<Sale, SaleResponseModel>()
                .ForMember(x => x.Credit, opts => opts.MapFrom(y => y.Kg * y.PriceKg - y.PayedAmount));
            CreateMap<Sale, Sale>();
        }
    }
}
