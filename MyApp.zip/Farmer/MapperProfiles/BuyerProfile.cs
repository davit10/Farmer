﻿using AutoMapper;
using FarmingApp.Models;
using FarmingApp.Models.Request_Models;
using FarmingApp.Models.Response_Model;

namespace FarmingApp.MapperProfiles
{
    public class BuyerProfile : Profile
    {
        public BuyerProfile()
        {
            CreateMap<BuyerRequestModel, Buyer>();
            CreateMap<Buyer, BuyerResponseModel>();
            CreateMap<Buyer, Buyer>();

        }
    }
}
