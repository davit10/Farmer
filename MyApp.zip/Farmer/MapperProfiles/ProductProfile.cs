﻿using AutoMapper;
using FarmingApp.Models;
using FarmingApp.Models.Request_Models;
using FarmingApp.Models.Response_Model;

namespace FarmingApp.MapperProfiles
{
    public class ProductProfile : Profile
    {
        public ProductProfile()
        {
            CreateMap<ProductRequestModel, Product>();
            CreateMap<Product, ProductResponseModel>();
            CreateMap<Product, Product>();
        }
    }
}
