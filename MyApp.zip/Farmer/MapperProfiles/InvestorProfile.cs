﻿using AutoMapper;
using FarmingApp.Models;
using FarmingApp.Models.Request_Models;
using FarmingApp.Models.Response_Model;

namespace FarmingApp.MapperProfiles
{
    public class InvestorProfile : Profile
    {
        public InvestorProfile()
        {
            CreateMap<InvestorRequestModel, Investor>()
            .ForMember(x => x.Date, opts => opts.MapFrom(y => DateTime.Now));
            CreateMap<Investor, InvestorResponseModel>();
            CreateMap<Investor, Investor>();
        }

    }
}
