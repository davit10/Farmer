﻿using AutoMapper;
using FarmingApp.Models;
using FarmingApp.Models.Request_Models;
using FarmingApp.Models.Response_Model;

namespace FarmingApp.MapperProfiles
{
    public class TreatmentProfile : Profile
    {
        public TreatmentProfile()
        {
            CreateMap<TreatmentRequestModel, Treatment>()
                .ForMember(x => x.Date, opts => opts.MapFrom(y => DateTime.Now));
            CreateMap<Treatment, TreatmentResponseModel>();
            CreateMap<Treatment, Treatment>();
        }
    }
}
