﻿using AutoMapper;
using FarmingApp.Models;
using FarmingApp.Repositories;

namespace FarmingApp.Services
{
    public interface IBuyerService
    {
        List<Buyer> GetBuyers();
        void AddBuyer(Buyer buyer);
        void DeleteBuyer(int id);
        void UpdateBuyer(Buyer buyer);
    }
    public class BuyerService : IBuyerService
    {

        IBuyerRepository _repo;
        //IMapper _mapper;

        public BuyerService(IBuyerRepository repo)
        {
            _repo = repo;
            //_mapper = mapper;


        }

        public List<Buyer> GetBuyers()
        {
            return _repo.GetAll();
        }

        public void AddBuyer(Buyer buyer)
        {
            _repo.Add(buyer);

        }
        public void DeleteBuyer(int id)
        {
            _repo.Delete(id);
        }

        public void UpdateBuyer(Buyer buyer)
        {
            _repo.Update(buyer);
        }
    }
}
