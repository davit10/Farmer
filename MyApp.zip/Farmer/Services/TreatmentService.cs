﻿using AutoMapper;
using FarmingApp.Models;
using FarmingApp.Repositories;

namespace FarmingApp.Services
{
    public interface ITreatmentService
    {
        List<Treatment> GetTreatments();
        void AddTreatment(Treatment treatment);
        void DeleteTreatment(int id);
        void UpdateTreatment(Treatment treatment);
    }
    public class TreatmentService : ITreatmentService
    {
        ITreatmentRepository repo;

        public TreatmentService(ITreatmentRepository r)
        {
            repo = r;

        }
        public List<Treatment> GetTreatments()
        {
            return repo.GetAll();
        }

        public void AddTreatment(Treatment treatment)
        {
            repo.Add(treatment);
        }

        public void DeleteTreatment(int id)
        {
            repo.Delete(id);
        }

        public void UpdateTreatment(Treatment treatment)
        {
            repo.Update(treatment);
        }
    }
}
