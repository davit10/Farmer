﻿using AutoMapper;
using FarmingApp.Models;
using FarmingApp.Repositories;

namespace FarmingApp.Services
{
    public interface IExpenseService
    {
        List<Expense> GetExpenses();
        void AddExpense(Expense expense);
        void DeleteExpense(int id);
        void UpdateExpense(Expense expense);
    }
    public class ExpenseService : IExpenseService
    {

        IExpenseRepository repo;

        public ExpenseService(IExpenseRepository _repo)
        {
            repo = _repo;

        }

        public List<Expense> GetExpenses()
        {
            return repo.GetAll();
        }

        public void AddExpense(Expense expense)
        {
            repo.Add(expense);
        }
        public void DeleteExpense(int id)
        {
            repo.Delete(id);
        }

        public void UpdateExpense(Expense expense)
        {
            repo.Update(expense);
        }
    }
}
