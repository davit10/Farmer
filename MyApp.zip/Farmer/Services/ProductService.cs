﻿using AutoMapper;
using FarmingApp.Models;
using FarmingApp.Repositories;

namespace FarmingApp.Services
{
    public interface IProductService
    {
        List<Product> GetProducts();
        void AddProducts(Product product);
        void DeleteProduct(int id);
        void UpdateProduct(Product product);
    }
    public class ProductService : IProductService
    {
        //IMapper _mapper;
        IProductRepository productRepository;


        public ProductService(IProductRepository repo)
        {
            productRepository = repo;
            //_mapper = mapper;


        }

        public List<Product> GetProducts()
        {
            return productRepository.GetAll();
        }

        public void AddProducts(Product product)
        {
            productRepository.Add(product);
        }

        public void DeleteProduct(int id)
        {
            productRepository.Delete(id);
        }

        public void UpdateProduct(Product pr)
        {
            productRepository.Update(pr);
        }
    }
}
