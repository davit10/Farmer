﻿using AutoMapper;
using FarmingApp.Models;
using FarmingApp.Repositories;

namespace FarmingApp.Services
{
    public interface IInvestorService
    {
        List<Investor> GetInvestors();
        void AddInvestors(Investor investor);
        void DeleteInvestor(int id);
        void UpdateInvestor(Investor investor);
    }
    public class InvestorService : IInvestorService
    {
        IInvestorRepository repo;
        public InvestorService(IInvestorRepository rep)
        {
            repo = rep;

        }

        public List<Investor> GetInvestors()
        {
            return repo.GetAll();
        }

        public void AddInvestors(Investor investor)
        {
            repo.Add(investor);
        }

        public void DeleteInvestor(int id)
        {
            repo.Delete(id);
        }

        public void UpdateInvestor(Investor investor)
        {
            repo.Update(investor);
        }
    }
}
