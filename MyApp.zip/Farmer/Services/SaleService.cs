﻿using AutoMapper;
using FarmingApp.Models;
using FarmingApp.Repositories;

namespace FarmingApp.Services
{
    public interface ISaleService
    {
        List<Sale> GetSales();
        void AddSales(Sale sale);
        void DeleteSale(int id);
        void UpdateSale(Sale sale);
    }

    public class SaleService : ISaleService 
    {
        ISaleRepository repo;

        public SaleService(ISaleRepository r)
        {
            repo = r;

        }

        public List<Sale> GetSales()
        {
            return repo.GetAll();
        }

        public void AddSales(Sale sale)
        {
            repo.Add(sale);
        }

        public void DeleteSale(int id)
        {
            repo.Delete(id);
        }

        public void UpdateSale(Sale sale)
        {
           repo.Update(sale);

        }
    }
}
