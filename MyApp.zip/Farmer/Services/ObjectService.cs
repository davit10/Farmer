﻿using AutoMapper;
using FarmingApp.Models;
using FarmingApp.Repositories;

namespace FarmingApp.Services
{
    public interface IObjectService
    {
        List<Objects> GetAll();
        void AddObjects(Objects objects);

        void DeleteObjects(int id);
        void UpdateObjects(Objects objects);
    }
    public class ObjectService : IObjectService
    {
        IObjectsRepository repo;
        public ObjectService(IObjectsRepository _repo)
        {
            repo = _repo;
        }

        public List<Objects> GetAll()
        {
            return repo.GetAll();
        }

        public void AddObjects(Objects objects)
        {
            repo.Add(objects);
        }

        public void DeleteObjects(int id)
        {
            repo.Delete(id);
        }

        public void UpdateObjects(Objects objects)
        {
            repo.Update(objects);
        }
    }
}
