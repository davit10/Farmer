﻿using FarmingApp.Models;
using Microsoft.EntityFrameworkCore;

namespace FarmingApp
{
    public class FarmerDbContext : DbContext
    {
        public DbSet<Product> Products { get; set; }
        public DbSet<Buyer> Buyers { get; set; }
        public DbSet<Sale> Sales { get; set; }
        public DbSet<Expense> Expenses { get; set; }
        public DbSet<Investor> Investors { get; set; }
        public DbSet<Objects> Objects { get; set; }
        public DbSet<Treatment> Treatments { get; set; }

        public FarmerDbContext(DbContextOptions<FarmerDbContext> options) : base(options)
        {

        }

    }
}
