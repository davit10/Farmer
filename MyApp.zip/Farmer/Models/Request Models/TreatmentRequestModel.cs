﻿namespace FarmingApp.Models.Request_Models
{
    public class TreatmentRequestModel
    {
        public int ObjectId { get; set; }
        public string Name { get; set; }
        public double Weight { get; set; }
        public string Describtion { get; set; }
    }
}
