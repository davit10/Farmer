﻿namespace FarmingApp.Models.Request_Models
{
    public class SaleRequestModel
    {
        public int ProductId { get; set; }
        public double Kg { get; set; }
        public int PriceKg { get; set; }
        public int BuyerId { get; set; }
        public int PayedAmount { get; set; }
    }
}
