﻿namespace FarmingApp.Models.Request_Models
{
    public class ObjectsRequestModel
    {
        public string Name { get; set; }
        public string Type { get; set; }
    }
}
