﻿namespace FarmingApp.Models.Request_Models
{
    public class InvestorRequestModel
    {
        public string Name { get; set; }
        public int Amount { get; set; }
        public DateTime Date { get; set; }
        public string Phone { get; set; }
    }
}
