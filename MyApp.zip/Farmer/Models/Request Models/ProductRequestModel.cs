﻿namespace FarmingApp.Models.Request_Models
{
    public class ProductRequestModel
    {
        public string Name { get; set; }
        public int PriceKg { get; set; }
    }
}
