﻿namespace FarmingApp.Models.Request_Models
{
    public class ExpenseRequestModel
    {
        public string Name { get; set; }
        public int Amount { get; set; }
        public DateTime Date { get; set; }
        public string Describtion { get; set; }
        public string Type { get; set; }
    }
}
