﻿namespace FarmingApp.Models.Response_Model
{
    public class TreatmentResponseModel
    {
        public int Id { get; set; }
        public int ObjectId { get; set; }
        public string Name { get; set; }
        public double Weight { get; set; }
        public Objects Object { get; set; }
        public DateTime Date { get; set; }
        public string Describtion { get; set; }
    }
}
