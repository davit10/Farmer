﻿namespace FarmingApp.Models.Response_Model
{
    public class ProductResponseModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int PriceKg { get; set; }
        public ICollection<Sale> Sales { get; set; }
    }
}
