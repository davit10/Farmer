﻿namespace FarmingApp.Models.Response_Model
{
    public class SaleResponseModel
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public Product Product { get; set; }
        public double Kg { get; set; }
        public int PriceKg { get; set; }
        public int BuyerId { get; set; }
        public Buyer Buyer { get; set; }
        public DateTime Date { get; set; }
        public int PayedAmount { get; set; }
        public double Credit { get; set; }
    }
}
