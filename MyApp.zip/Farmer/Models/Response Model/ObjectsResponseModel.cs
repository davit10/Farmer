﻿namespace FarmingApp.Models.Response_Model
{
    public class ObjectsResponseModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
    }
}
