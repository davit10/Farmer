﻿namespace FarmingApp.Models
{
    public class Expense
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Amount { get; set; }
        public DateTime Date { get; set; }
        public string Describtion { get; set; }
        public string Type { get; set; }
    }
}
