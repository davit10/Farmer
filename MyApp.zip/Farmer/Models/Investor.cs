﻿namespace FarmingApp.Models
{
    public class Investor
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Amount { get; set; }
        public DateTime Date { get; set; }
        public string Phone { get; set; }
    }
}
